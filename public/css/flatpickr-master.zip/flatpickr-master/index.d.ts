import { FlatpickrFn } from "./src/types/instance";
export { Instance } from "./src/types/instance";
export * from "./src/types/options";

declare var flatpickr: FlatpickrFn;

export default flatpickr;
